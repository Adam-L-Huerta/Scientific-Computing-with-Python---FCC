def arithmetic_arranger(problems, solve=False):
  
    arranged_problems = []

    # Validate input
    is_valid = validate_input(problems)

    if is_valid == "":
        arranged_problems = arrange(problems, solve)
        return arranged_problems
    else:
        return is_valid

# list -> String
# Create 4 strings to be printed
# top, mid, bottom, solution
# Collects data into String to be returned

def arrange(problems, solve=False):

  # list of lists to collect data before adding to a string
  # operand1, operator, operand2, dashes, answer 
  arranged = [['','','','',''],
              ['','','','',''],
              ['','','','',''],
              ['','','','',''],
              ['','','','','']]
  
  index = 0 # index of problem in list

  # initialize strings to collect list contents after formatting
  line1 = "" # operand1
  line2 = "" # operator + operand2
  line3 = "" # dashes
  line4 = "" # solutions

  # only solve and add to list if solve = True
  if solve:
      solutions = solve_problems(problems)
      for i in range(len(solutions)):
          arranged[i][4] = str(solutions[i]);
    
  # iterate through problems
  for i in problems:

    # Splitting individual problems into operands and operator
    li = list(i.split(" "))
   
    operand1 = li[0] 
    operator = li[1] 
    operand2 = li[2] 

    # Adding appropriate spaces to each and storing in list
    if len(operand1) > len(operand2):  # is operand1 longer than operand2
        arranged[index][0] = " "*2 + operand1 
        arranged[index][1] = operator + " "
        arranged[index][2] = " "*(len(arranged[index][0])-len(operand2)-2) + operand2
    else: 
        arranged[index][1] = operator + " "
        arranged[index][2] = operand2 
        arranged[index][0] = " "*(len(arranged[index][2]) + 2 - len(operand1)) + operand1

    arranged[index][3] = "-"*(len(arranged[index][2]) + 2)
    
    if solve:
      arranged[index][4] = " "*((len(arranged[index][3])) - (len(arranged[index][4]))) + arranged[index][4]
    index+=1;

  
  # collect list contents into individual strings with 4 spaces in between each problem
  for i in range(index):
      line1 += arranged[i][0] + " "*4
      line2 += arranged[i][1] + arranged[i][2] + " "*4
      line3 += arranged[i][3] + " "*4
      line4 += arranged[i][4] + " "*4

  # combine all lines into single output string to be returned
  # removes trailing spaces from end of line
  output = line1.rstrip() + '\n' + line2.rstrip() + '\n' + line3.rstrip()
  if solve:
      output += '\n' + line4.rstrip()

  return output

# list -> list
# Evaluates each problem in list and appends solution to returned list sol
def solve_problems(problems):
  sol =[]
  for i in problems:
    sol.append(eval(i))
  return sol

# list -> String
# Examines given problems against error conditions.
# Returns empty string if no error found. 
def validate_input(problems):
  
  if is_too_many_problems(problems):
    return "Error: Too many problems."
  elif is_not_add_or_sub(problems):
    return "Error: Operator must be '+' or '-'."
  elif is_not_only_digits(problems):
    return "Error: Numbers must only contain digits."
  elif is_not_less_than_five_digits(problems):
    return "Error: Numbers cannot be more than four digits."
  else:
    return ""
  

# list -> bool 
# Returns true if there are too many problems (more than 5) supplied to the function. 
def is_too_many_problems(problems):
  if len(problems) > 5:
    return True
  else:
    return False


# list -> bool 
# The appropriate operators the function will accept are addition and subtraction. 
# Multiplication and division will return true. 
def is_not_add_or_sub(problems):
  for i in problems:
    if "/" in i or '*' in i:
      return True
  return False


# list -> bool 
# Each number (operand) should only contain digits. If not, returns true
def is_not_only_digits(problems):
  for i in problems:
     try:
      eval(i)
     except:
       return True
  return False


# list -> bool
# Each operand (aka number on each side of the operator) has a max of four digits in width. 
# If more than 4 digits, returns true
def is_not_less_than_five_digits(problems):
  for i in problems:
    li = list(i.split(" "))
    for n in li:
      if len(n) > 4:
        return True
  return False